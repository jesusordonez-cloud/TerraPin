from pathlib import Path
import re, json
import sys
root=Path(sys.argv[1] if len(sys.argv)>1 else 'terrapin')
app_p=root/'app.js'; idx_p=root/'index.html'; sw_p=root/'sw.js'; pkg_p=root/'package.json'; man_p=root/'manifest.json'
app=app_p.read_text(); idx=idx_p.read_text(); sw=sw_p.read_text(); pkg=pkg_p.read_text(); man=man_p.read_text()

# versions
pkg=pkg.replace('"version": "2.4.0"','"version": "2.5.0"')
app=app.replace('/* TerraPin 2.4', '/* TerraPin 2.5') if '/* TerraPin 2.4' in app else app
app=app.replace('v2.4</span>', 'v2.5</span>')
idx=idx.replace('SIG FIELD</span>', 'FIELD GIS <b>2.5</b></span>')
sw=sw.replace("terrapin-shell-v2.4", "terrapin-shell-v2.5")

# routing replacement
start=app.index('const localRoutes = (from,to) => {')
end=app.index("$('#routeClose').onclick=closeNavigation;", start)
new_route=r'''const localRoutes = (from,to) => {
  const g=buildLocalGraph(); if(g.nodes.length<2)return [];
  const a=nearestGraphNode(g,from),b=nearestGraphNode(g,to); if(a.i<0||b.i<0||a.d>3000)return [];
  const penalty=new Map(), out=[];
  for(let k=0;k<3;k++){
    const r=aStar(g,a.i,b.i,penalty); if(!r)break;
    const core=r.ids.map(i=>g.nodes[i]); if(core.length<1)break;
    const sig=r.ids.join('-'); if(out.some(x=>x.sig===sig))break;
    const startLink=a.d>8?[[from.lat,from.lng],core[0]]:null;
    const directTail=b.d>8?[core.at(-1),[to.lat,to.lng]]:null;
    const roadDist=routeDistance(core), startLinkDist=startLink?routeDistance(startLink):0, offRoadDist=directTail?routeDistance(directTail):0;
    const coords=[]; if(startLink)coords.push(startLink[0]); coords.push(...core); if(directTail)coords.push(directTail[1]);
    const dist=roadDist+startLinkDist+offRoadDist;
    const dur=roadDist/(25/3.6)+(startLinkDist+offRoadDist)/(5/3.6);
    const tailText=offRoadDist>8?` · tramo directo final ${fmtDist(offRoadDist)}`:'';
    out.push({id:'local-'+k,source:'local',label:k?'Red SIG · alternativa '+(k+1):'Red SIG local',detail:`${localLineSources().length} líneas cargadas${tailText}`,coords,mainCoords:core,startLink,directTail,roadDist,startLinkDist,offRoadDist,dist,dur,sig,snap:a.d+b.d});
    for(let i=1;i<r.ids.length;i++){const ek=edgeKey(r.ids[i-1],r.ids[i]);penalty.set(ek,(penalty.get(ek)||0)+.75);}
  }
  return out;
};
const onlineRoutes = async (from,to) => {
  if(!navigator.onLine)return [];
  const u=`https://router.project-osrm.org/route/v1/driving/${from.lng},${from.lat};${to.lng},${to.lat}?alternatives=3&steps=true&geometries=geojson&overview=full`;
  try{
    const r=await fetch(u); if(!r.ok)return[]; const j=await r.json(); if(j.code!=='Ok'||!j.routes?.length)return[];
    const startSnap=j.waypoints?.[0]?.location?[j.waypoints[0].location[1],j.waypoints[0].location[0]]:[from.lat,from.lng];
    const endSnap=j.waypoints?.[1]?.location?[j.waypoints[1].location[1],j.waypoints[1].location[0]]:[to.lat,to.lng];
    return j.routes.map((q,i)=>{
      const main=q.geometry.coordinates.map(c=>[c[1],c[0]]);
      const startD=hav([from.lat,from.lng],startSnap), endD=hav(endSnap,[to.lat,to.lng]);
      const startLink=startD>8?[[from.lat,from.lng],startSnap]:null;
      const directTail=endD>8?[endSnap,[to.lat,to.lng]]:null;
      const coords=[]; if(startLink)coords.push(startLink[0]); coords.push(...main); if(directTail)coords.push(directTail[1]);
      const extra=startD+endD, tailText=endD>8?` · tramo directo final ${fmtDist(endD)}`:'';
      return {id:'osm-'+i,source:'osm',label:i?'Calles OSM · alternativa '+(i+1):'Calles OSM',detail:(i?'Ruta vial alternativa':'Ruta recomendada por la red OSM')+tailText,coords,mainCoords:main,startLink,directTail,roadDist:q.distance,startLinkDist:startD,offRoadDist:endD,dist:q.distance+extra,dur:q.duration+extra/(5/3.6),steps:(q.legs||[]).flatMap(l=>l.steps||[])};
    });
  }catch(e){console.warn('OSRM',e);return[];}
};
const directRoute = (from,to) => ({id:'direct',source:'direct',label:'Orientación directa',detail:'No se identificó una red conectada hasta el destino',coords:[[from.lat,from.lng],[to.lat,to.lng]],mainCoords:[],directTail:[[from.lat,from.lng],[to.lat,to.lng]],offRoadDist:hav([from.lat,from.lng],[to.lat,to.lng]),dist:hav([from.lat,from.lng],[to.lat,to.lng]),dur:null});
const ensureCurrentLocation = () => new Promise((res,rej)=>{if(S.me)return res(S.me);if(!navigator.geolocation)return rej(new Error('GPS no disponible'));navigator.geolocation.getCurrentPosition(p=>{onPos(p);res(S.me)},rej,{enableHighAccuracy:true,timeout:25000,maximumAge:5000});});
const navRouteStyle = r => r.source==='direct'?{color:'#D59A38',weight:5,dashArray:'9 8'}:{color:'#19A987',weight:7};
const activateRoute = (route,target,routes) => {
  if(S.navLayer)map.removeLayer(S.navLayer);
  const g=L.layerGroup().addTo(map), style=navRouteStyle(route);
  const main=route.mainCoords?.length?route.mainCoords:(route.source==='direct'?[]:route.coords);
  if(route.startLink){g.addLayer(L.polyline(route.startLink,{color:'#fff',weight:8,opacity:.8,lineCap:'round'}));g.addLayer(L.polyline(route.startLink,{color:'#75847E',weight:3,dashArray:'4 6',opacity:.95,lineCap:'round'}));}
  if(main.length>1){g.addLayer(L.polyline(main,{color:'#fff',weight:style.weight+6,opacity:.9,lineCap:'round'}));g.addLayer(L.polyline(main,{color:'#19A987',weight:style.weight,opacity:.98,lineCap:'round'}));}
  if(route.directTail){g.addLayer(L.polyline(route.directTail,{color:'#fff',weight:9,opacity:.92,lineCap:'round'}));g.addLayer(L.polyline(route.directTail,{color:'#D59A38',weight:5,dashArray:'10 8',opacity:1,lineCap:'round'}));}
  if(route.source==='direct'&&!main.length&&!route.directTail){g.addLayer(L.polyline(route.coords,{...style,opacity:.98,lineCap:'round'}));}
  g.addLayer(L.circleMarker([target.lat,target.lng],{radius:9,color:'#fff',weight:3,fillColor:'#D59A38',fillOpacity:1}));
  S.navLayer=g; S.nav={target,route,routes}; renderRouteCard(); const b=L.latLngBounds(route.coords); if(b.isValid())map.fitBounds(b,{paddingTopLeft:[28,150],paddingBottomRight:[28,205]}); startGPS(); updateNavigationProgress(S.me||L.latLng(route.coords[0]));
};
const closeNavigation = () => {if(S.navLayer){map.removeLayer(S.navLayer);S.navLayer=null;}S.nav=null;navCard.classList.remove('open');};
const switchRoute = id => {if(!S.nav)return;const r=S.nav.routes.find(x=>x.id===id);if(r)activateRoute(r,S.nav.target,S.nav.routes);};
const renderRouteCard = () => {
  if(!S.nav)return navCard.classList.remove('open');const {route,target,routes}=S.nav;navCard.classList.add('open');
  $('#routeTitle').textContent=target.name||'Destino'; $('#routeSource').textContent=route.label; $('#routeDist').textContent=fmtDist(route.dist); $('#routeEta').textContent=route.dur?fmtTime(route.dur):'—'; $('#routeRemain').textContent=fmtDist(route.dist);
  const tn=$('#routeTailNote'); if(tn){tn.textContent=route.offRoadDist>8?`Último tramo: ${fmtDist(route.offRoadDist)} en línea recta hasta el punto`:(route.source==='direct'?'Ruta completa en línea recta':'La red llega al destino');tn.classList.toggle('visible',true);tn.classList.toggle('direct',route.offRoadDist>8||route.source==='direct');}
  $('#routeChoices').innerHTML=routes.map(r=>`<button class="route-choice ${r.id===route.id?'active':''}" data-route="${r.id}"><b>${esc(r.label)}</b><span>${fmtDist(r.dist)}${r.offRoadDist>8?' · '+fmtDist(r.offRoadDist)+' directo':''}${r.dur?' · '+fmtTime(r.dur):''}</span></button>`).join('');
  $('#routeChoices').querySelectorAll('[data-route]').forEach(b=>b.onclick=()=>switchRoute(b.dataset.route));
};
const updateNavigationProgress = ll => {
  if(!S.nav||!ll)return;const r=S.nav.route;let bi=0,bd=Infinity;for(let i=0;i<r.coords.length;i++){const d=hav([ll.lat,ll.lng],r.coords[i]);if(d<bd){bd=d;bi=i}}let rem=hav([ll.lat,ll.lng],r.coords[bi]);for(let i=bi+1;i<r.coords.length;i++)rem+=hav(r.coords[i-1],r.coords[i]);$('#routeRemain').textContent=fmtDist(rem);const eta=r.dur&&r.dist?Math.max(0,r.dur*(rem/r.dist)):null;$('#routeEta').textContent=eta?fmtTime(eta):'—';const status=$('#routeStatus');const inTail=r.directTail&&hav([ll.lat,ll.lng],r.directTail[0])<Math.max(120,r.offRoadDist*.45);status.textContent=rem<35?'Destino muy cerca':inTail?'Tramo final directo al punto':bd>120?'Fuera de ruta · conviene recalcular':'Navegación activa';status.classList.toggle('warn',bd>120||inTail);
};
const chooseRouteDialog = (routes,target) => {
  const cards=routes.map((r,i)=>`<button class="route-option-card" data-pickroute="${r.id}"><span class="route-net ${r.source}">${r.source==='local'?'SIG':r.source==='osm'?'OSM':'↗'}</span><span class="grow"><b>${esc(r.label)}</b><small>${esc(r.detail||'')} · ${fmtDist(r.dist)}${r.dur?' · '+fmtTime(r.dur):''}</small></span><span>›</span></button>`).join('');
  openModal(`<div class="modal-kicker">NAVEGACIÓN</div><h3>Ruta a ${esc(target.name||'punto')}</h3><p class="muted">TerraPin seguirá la red identificada hasta donde sea posible. Si ningún camino llega exactamente al punto, mostrará un tramo final ámbar en línea recta.</p><div class="route-option-list">${cards}</div><div class="actions"><button class="btn ghost" data-close>Cancelar</button></div>`);document.querySelectorAll('[data-pickroute]').forEach(b=>b.onclick=()=>{const r=routes.find(x=>x.id===b.dataset.pickroute);closeModal();activateRoute(r,target,routes);});
};
const routeToWaypoint = async w => {
  toast('Analizando caminos y rutas…');try{const from=await ensureCurrentLocation();const [local,osm]=await Promise.all([Promise.resolve(localRoutes(from,L.latLng(w.lat,w.lng))),onlineRoutes(from,L.latLng(w.lat,w.lng))]);let routes=[...local,...osm];if(!routes.length)routes=[directRoute(from,L.latLng(w.lat,w.lng))];routes.sort((a,b)=>{if(a.source==='direct')return 1;if(b.source==='direct')return-1;return (a.dur||a.dist)-(b.dur||b.dist)});if(routes.length===1)activateRoute(routes[0],w,routes);else chooseRouteDialog(routes,w);}catch(e){console.error(e);toast('No se pudo obtener tu ubicación para navegar');}
};
'''
app=app[:start]+new_route+app[end:]

# Replace report block fully
rstart=app.index('/* ---------- reportes PDF e impresión ---------- */')
rend=app.index('\nconst projName = id =>', rstart)
report=r'''/* ---------- mapa PDF profesional e impresión ---------- */
const safeFile = s => String(s || 'mapa').normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-zA-Z0-9_-]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 70) || 'mapa';
const hexRgb = h => { h = String(h || '#0F766E').replace('#', ''); if (h.length === 3) h = h.split('').map(c => c + c).join(''); const n = parseInt(h, 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
const paleRgb = h => hexRgb(h).map(v=>Math.round(v*.28+255*.72));
const pointPdfStyle = icon => ({pin:['P','#0F766E'],tree:['A','#3B7A57'],forest:['B','#2F6B48'],water:['H','#2D78B7'],camera:['F','#6B5CA5'],house:['S','#8B5E3C'],camp:['C','#9A6B27'],vehicle:['V','#4B5563'],trail:['R','#A06B2B'],wildlife:['Fa','#7C5A3C'],warning:['!','#C46B2B'],check:['✓','#287A67']}[icon]||['P','#0F766E']);
const reportScope = (projectId,areaOverride=null) => {
  const project = projectId ? S.projects.find(p => p.id === projectId) : null;
  const tracks = projectId ? S.tracks.filter(t => t.projectId === projectId) : S.tracks.slice();
  const waypoints = projectId ? S.waypoints.filter(w => w.projectId === projectId) : S.waypoints.slice();
  const vectors = projectId ? S.vectors.filter(v => v.projectId === projectId) : S.vectors.slice();
  const title = project ? project.name : 'Mapa general de campo';
  const areaName = areaOverride ?? project?.areaName ?? S.settings.reportAreaName ?? 'Área de trabajo';
  const totalDist = tracks.reduce((a, t) => a + trackStats(t).dist, 0);
  const totalTime = tracks.reduce((a, t) => a + trackStats(t).dur, 0);
  return { project, tracks, waypoints, vectors, title, areaName, totalDist, totalTime };
};
const geomCoordSets = g => {
  if(!g)return[];
  if(g.type==='Point')return [[[g.coordinates[1],g.coordinates[0]]]];
  if(g.type==='MultiPoint')return g.coordinates.map(c=>[[c[1],c[0]]]);
  if(g.type==='LineString')return [g.coordinates.map(c=>[c[1],c[0]])];
  if(g.type==='MultiLineString')return g.coordinates.map(r=>r.map(c=>[c[1],c[0]]));
  if(g.type==='Polygon')return g.coordinates.map(r=>r.map(c=>[c[1],c[0]]));
  if(g.type==='MultiPolygon')return g.coordinates.flatMap(p=>p.map(r=>r.map(c=>[c[1],c[0]])));
  return[];
};
const reportBounds = (tracks, waypoints, vectors=[]) => {
  const pts=[...tracks.flatMap(t=>t.points.map(p=>[p[0],p[1]])),...waypoints.map(w=>[w.lat,w.lng]),...vectors.flatMap(v=>geomCoordSets(v.feature?.geometry).flat())];
  if(!pts.length)return null;let minLat=Infinity,maxLat=-Infinity,minLng=Infinity,maxLng=-Infinity;pts.forEach(([lat,lng])=>{if(!Number.isFinite(lat)||!Number.isFinite(lng))return;minLat=Math.min(minLat,lat);maxLat=Math.max(maxLat,lat);minLng=Math.min(minLng,lng);maxLng=Math.max(maxLng,lng)});if(!Number.isFinite(minLat))return null;
  if(maxLat===minLat){maxLat+=.0005;minLat-=.0005} if(maxLng===minLng){maxLng+=.0005;minLng-=.0005}
  const py=(maxLat-minLat)*.08,px=(maxLng-minLng)*.08;return{minLat:minLat-py,maxLat:maxLat+py,minLng:minLng-px,maxLng:maxLng+px};
};
const niceScale = m => { if(!Number.isFinite(m)||m<=0)return 100;const e=10**Math.floor(Math.log10(m)),q=m/e;return(q>=5?5:q>=2?2:1)*e; };
const reportProjection = (b,x,y,w,h) => {const dx=b.maxLng-b.minLng,dy=b.maxLat-b.minLat,sc=Math.min(w/dx,h/dy),ox=x+(w-dx*sc)/2,oy=y+(h-dy*sc)/2;return p=>[ox+(p[1]-b.minLng)*sc,y+h-((oy-y)+(p[0]-b.minLat)*sc)];};
const reportLegendData = d => {
  const points=[...new Set(d.waypoints.map(w=>w.icon||'pin'))].map(i=>({type:'point',icon:i,label:pointIconDef(i).label,color:pointPdfStyle(i)[1]}));
  const tracks=d.tracks.slice(0,8).map(t=>({type:'line',label:t.name,color:t.color||'#0F766E'}));
  const vectors=d.vectors.slice(0,10).map(v=>({type:v.feature?.geometry?.type?.includes('Polygon')?'polygon':'vector',label:v.name||vectorName(v.feature),color:v.color||'#7C5CE0'}));
  return {points,tracks,vectors};
};
const reportSvg = d => {
  const b=reportBounds(d.tracks,d.waypoints,d.vectors);if(!b)return '<div class="nomap">Sin geometrías para representar</div>';
  const W=1180,H=650,P=42,xy=reportProjection(b,P,P,W-P*2,H-P*2);let shapes='';
  for(const v of d.vectors){const g=v.feature?.geometry,col=esc(v.color||'#7C5CE0');for(const set of geomCoordSets(g)){if(!set.length)continue;const pts=set.map(p=>xy(p).map(n=>n.toFixed(1)).join(',')).join(' ');if(g.type?.includes('Polygon'))shapes+=`<polygon points="${pts}" fill="${col}" fill-opacity=".16" stroke="${col}" stroke-width="3"/>`;else shapes+=`<polyline points="${pts}" fill="none" stroke="${col}" stroke-width="4" stroke-linecap="round"/>`;}}
  for(const t of d.tracks){const pts=t.points.map(p=>xy(p).map(n=>n.toFixed(1)).join(',')).join(' ');shapes+=`<polyline points="${pts}" fill="none" stroke="#fff" stroke-width="9" stroke-linecap="round"/><polyline points="${pts}" fill="none" stroke="${esc(t.color||'#0F766E')}" stroke-width="5" stroke-linecap="round"/>`;}
  d.waypoints.forEach((w,i)=>{const [x,y]=xy([w.lat,w.lng]),[code,col]=pointPdfStyle(w.icon);shapes+=`<circle cx="${x}" cy="${y}" r="12" fill="${col}" stroke="#fff" stroke-width="4"/><text x="${x}" y="${y+4}" text-anchor="middle" font-size="10" font-weight="800" fill="#fff">${esc(code)}</text>`;});
  const mid=(b.minLat+b.maxLat)/2,widthM=hav([mid,b.minLng],[mid,b.maxLng]),scaleM=niceScale(widthM*.22),scalePx=(scaleM/widthM)*(W-P*2);const scaleLabel=scaleM>=1000?(scaleM/1000)+' km':Math.round(scaleM)+' m';
  return `<svg viewBox="0 0 ${W} ${H}" class="carto-svg"><rect width="${W}" height="${H}" rx="24" fill="#F3F1EA"/><g stroke="#D8D5CC" stroke-width="1">${[1,2,3].map(i=>`<path d="M${P} ${P+i*(H-P*2)/4}H${W-P}"/><path d="M${P+i*(W-P*2)/4} ${P}V${H-P}"/>`).join('')}</g>${shapes}<g transform="translate(${W-95},75)"><circle r="34" fill="#fff" stroke="#16211D" stroke-width="2"/><path d="M0-27L8 3L0-3L-8 3Z" fill="#16211D"/><path d="M0 27L8-3L0 3L-8-3Z" fill="#C8A86B"/><text x="0" y="-40" text-anchor="middle" font-size="18" font-weight="900" fill="#16211D">N</text><text x="0" y="51" text-anchor="middle" font-size="13" fill="#59645F">S</text><text x="45" y="4" text-anchor="middle" font-size="13" fill="#59645F">E</text><text x="-45" y="4" text-anchor="middle" font-size="13" fill="#59645F">O</text></g><g transform="translate(${P+18},${H-42})"><rect x="-12" y="-24" width="${scalePx+24}" height="34" rx="10" fill="#fff" fill-opacity=".88"/><path d="M0 0H${scalePx}" stroke="#16211D" stroke-width="6"/><path d="M0-5V5M${scalePx/2}-5V5M${scalePx}-5V5" stroke="#16211D" stroke-width="2"/><text x="${scalePx/2}" y="-10" text-anchor="middle" font-size="14" font-weight="800" fill="#16211D">${scaleLabel}</text></g><rect x="${P}" y="${P}" width="${W-P*2}" height="${H-P*2}" fill="none" stroke="#16211D" stroke-width="2"/></svg>`;
};
const logoDataUrl = async () => {const img=new Image();img.src='icon-512.png';await img.decode();const c=document.createElement('canvas');c.width=c.height=512;c.getContext('2d').drawImage(img,0,0,512,512);return c.toDataURL('image/png');};
const drawNorthRose=(doc,x,y)=>{doc.setDrawColor(25,34,31);doc.setFillColor(255,255,255);doc.circle(x,y,8,'FD');doc.setFillColor(25,34,31);doc.triangle(x,y-7,x+2.2,y+1,x,y-1.2,'F');doc.setFillColor(197,166,107);doc.triangle(x,y+7,x-2.2,y-1,x,y+1.2,'F');doc.setTextColor(25,34,31);doc.setFont('helvetica','bold');doc.setFontSize(7);doc.text('N',x,y-10,{align:'center'});doc.setFont('helvetica','normal');doc.setFontSize(5);doc.text('S',x,y+11,{align:'center'});doc.text('E',x+11,y+1.5,{align:'center'});doc.text('O',x-11,y+1.5,{align:'center'});};
const drawScaleBar=(doc,b,x,y,w)=>{const mid=(b.minLat+b.maxLat)/2,widthM=hav([mid,b.minLng],[mid,b.maxLng]),scaleM=niceScale(widthM*.22),bar=Math.min(w*.27,w*(scaleM/widthM));doc.setFillColor(255,255,255);doc.roundedRect(x-2,y-7,bar+4,12,2,2,'F');doc.setDrawColor(24,34,30);doc.setLineWidth(1.8);doc.line(x,y,x+bar,y);doc.setLineWidth(.5);[0,.5,1].forEach(f=>doc.line(x+bar*f,y-2,x+bar*f,y+2));doc.setFont('helvetica','bold');doc.setFontSize(5.5);doc.setTextColor(24,34,30);doc.text(scaleM>=1000?`${scaleM/1000} km`:`${Math.round(scaleM)} m`,x+bar/2,y-3,{align:'center'});};
const drawPdfMap=(doc,d,x,y,w,h)=>{
  const b=reportBounds(d.tracks,d.waypoints,d.vectors);doc.setFillColor(243,241,234);doc.roundedRect(x,y,w,h,3,3,'F');doc.setDrawColor(35,47,42);doc.setLineWidth(.45);doc.roundedRect(x,y,w,h,3,3,'S');if(!b){doc.setTextColor(100);doc.setFontSize(9);doc.text('Sin geometrías para representar',x+8,y+12);return null;}
  const xy=reportProjection(b,x+4,y+4,w-8,h-8);doc.setDrawColor(218,215,207);doc.setLineWidth(.18);for(let i=1;i<4;i++){doc.line(x+4,y+4+i*(h-8)/4,x+w-4,y+4+i*(h-8)/4);doc.line(x+4+i*(w-8)/4,y+4,x+4+i*(w-8)/4,y+h-4)}
  for(const v of d.vectors){const g=v.feature?.geometry,rgb=hexRgb(v.color),pale=paleRgb(v.color);for(const set of geomCoordSets(g)){if(set.length<1)continue;if(g.type?.includes('Polygon')){doc.setDrawColor(...rgb);doc.setFillColor(...pale);doc.setLineWidth(.65);const pts=set.map(xy);for(let i=1;i<pts.length;i++)doc.line(pts[i-1][0],pts[i-1][1],pts[i][0],pts[i][1]);if(pts.length>2){doc.line(pts.at(-1)[0],pts.at(-1)[1],pts[0][0],pts[0][1]);}}else{doc.setDrawColor(...rgb);doc.setLineWidth(.75);const pts=set.map(xy);for(let i=1;i<pts.length;i++)doc.line(pts[i-1][0],pts[i-1][1],pts[i][0],pts[i][1]);}}}
  for(const t of d.tracks){const pts=t.points.map(p=>xy([p[0],p[1]])),rgb=hexRgb(t.color);doc.setDrawColor(255,255,255);doc.setLineWidth(2.6);for(let i=1;i<pts.length;i++)doc.line(pts[i-1][0],pts[i-1][1],pts[i][0],pts[i][1]);doc.setDrawColor(...rgb);doc.setLineWidth(1.35);for(let i=1;i<pts.length;i++)doc.line(pts[i-1][0],pts[i-1][1],pts[i][0],pts[i][1]);}
  d.waypoints.forEach((wp,i)=>{const q=xy([wp.lat,wp.lng]),[code,col]=pointPdfStyle(wp.icon),rgb=hexRgb(col);doc.setFillColor(...rgb);doc.setDrawColor(255,255,255);doc.setLineWidth(.8);doc.circle(q[0],q[1],2.5,'FD');doc.setTextColor(255,255,255);doc.setFont('helvetica','bold');doc.setFontSize(code.length>1?3.2:4.5);doc.text(code,q[0],q[1]+1.2,{align:'center'});});
  drawNorthRose(doc,x+w-16,y+17);drawScaleBar(doc,b,x+8,y+h-8,w-20);doc.setFont('helvetica','normal');doc.setFontSize(4.5);doc.setTextColor(89,99,94);doc.text(`${b.maxLat.toFixed(5)}, ${b.minLng.toFixed(5)}`,x+4,y+3);doc.text(`${b.minLat.toFixed(5)}, ${b.maxLng.toFixed(5)}`,x+w-4,y+h-2,{align:'right'});return b;
};
const drawPdfLegend=(doc,d,x,y,w,h,b)=>{doc.setFillColor(250,249,245);doc.roundedRect(x,y,w,h,3,3,'F');doc.setDrawColor(224,220,210);doc.roundedRect(x,y,w,h,3,3,'S');let yy=y+8;const section=t=>{doc.setTextColor(27,37,33);doc.setFont('helvetica','bold');doc.setFontSize(7);doc.text(t,x+5,yy);yy+=5};const row=(label,color,type='line',code='')=>{if(yy>y+h-28)return;const rgb=hexRgb(color);if(type==='polygon'){doc.setFillColor(...paleRgb(color));doc.setDrawColor(...rgb);doc.rect(x+5,yy-2.4,7,4,'FD')}else if(type==='point'){doc.setFillColor(...rgb);doc.circle(x+8.5,yy-.5,2.3,'F');doc.setTextColor(255,255,255);doc.setFont('helvetica','bold');doc.setFontSize(3);doc.text(code,x+8.5,yy+.3,{align:'center'})}else{doc.setDrawColor(...rgb);doc.setLineWidth(1.1);doc.line(x+5,yy-.5,x+12,yy-.5)}doc.setTextColor(70,81,76);doc.setFont('helvetica','normal');doc.setFontSize(5.5);doc.text(String(label).slice(0,34),x+15,yy);yy+=5.2};
  section('SIMBOLOGÍA'); const lg=reportLegendData(d); if(lg.tracks.length){doc.setFontSize(5.3);doc.setTextColor(115);doc.text('Rutas registradas',x+5,yy);yy+=4;lg.tracks.forEach(e=>row(e.label,e.color));} if(lg.vectors.length){yy+=1;doc.setFontSize(5.3);doc.setTextColor(115);doc.text('Capas SIG',x+5,yy);yy+=4;lg.vectors.forEach(e=>row(e.label,e.color,e.type));} if(lg.points.length){yy+=1;doc.setFontSize(5.3);doc.setTextColor(115);doc.text('Puntos',x+5,yy);yy+=4;lg.points.forEach(e=>{const [code,col]=pointPdfStyle(e.icon);row(e.label,col,'point',code)});}
  const metaY=Math.max(yy+4,y+h-43);doc.setDrawColor(224,220,210);doc.line(x+5,metaY-4,x+w-5,metaY-4);doc.setTextColor(27,37,33);doc.setFont('helvetica','bold');doc.setFontSize(6);doc.text('INFORMACIÓN CARTOGRÁFICA',x+5,metaY);doc.setFont('helvetica','normal');doc.setTextColor(82,93,88);doc.setFontSize(5.2);const rows=[`Área: ${d.areaName}`,`CRS: WGS 84 · EPSG:4326`,`Fecha: ${new Date().toLocaleDateString('es-MX')}`,`Rutas: ${d.tracks.length} · Puntos: ${d.waypoints.length}`,`Capas SIG: ${d.vectors.length}`,b?`Extensión N ${b.maxLat.toFixed(4)} · S ${b.minLat.toFixed(4)}`:''];rows.filter(Boolean).forEach((s,i)=>doc.text(s,x+5,metaY+5+i*4));};
const createReportPdf = async (projectId,areaOverride=null) => {
  if(!window.jspdf?.jsPDF)throw new Error('Motor PDF no disponible');const data=reportScope(projectId,areaOverride),{jsPDF}=window.jspdf;const doc=new jsPDF({orientation:'landscape',unit:'mm',format:'a4',compress:true});const W=297,H=210,M=10;const logo=await logoDataUrl().catch(()=>null);
  doc.setFillColor(16,23,20);doc.roundedRect(M,M,W-M*2,23,5,5,'F');if(logo)doc.addImage(logo,'PNG',M+5,M+3,17,17);doc.setTextColor(255,255,255);doc.setFont('helvetica','bold');doc.setFontSize(15);doc.text(data.title,M+27,M+9);doc.setFontSize(8);doc.setTextColor(211,226,219);doc.text(data.areaName,M+27,M+15);doc.setFont('helvetica','normal');doc.setFontSize(6);doc.text(`MAPA DE PRESENTACIÓN · TerraPin Field GIS · ${new Date().toLocaleDateString('es-MX')}`,W-M-5,M+10,{align:'right'});doc.setTextColor(197,166,107);doc.text('CARTOGRAFÍA DE CAMPO',W-M-5,M+16,{align:'right'});
  const mapX=M,mapY=39,mapW=205,mapH=151,legX=221,legW=66;const b=drawPdfMap(doc,data,mapX,mapY,mapW,mapH);drawPdfLegend(doc,data,legX,mapY,legW,mapH,b);doc.setDrawColor(204,200,190);doc.line(M,197,W-M,197);doc.setTextColor(91,99,95);doc.setFont('helvetica','normal');doc.setFontSize(5.2);doc.text('Fuente: datos levantados en TerraPin y capas GIS importadas. Croquis vectorial; la disponibilidad de mapa base depende de las capas descargadas.',M,202);doc.text('Norte geográfico · Escala gráfica aproximada',W-M,202,{align:'right'});
  // page 2 - inventory
  doc.addPage('a4','landscape');doc.setFillColor(16,23,20);doc.rect(0,0,W,25,'F');if(logo)doc.addImage(logo,'PNG',M,4,17,17);doc.setTextColor(255,255,255);doc.setFont('helvetica','bold');doc.setFontSize(14);doc.text('Inventario cartográfico',M+23,11);doc.setFontSize(8);doc.setTextColor(211,226,219);doc.text(`${data.title} · ${data.areaName}`,M+23,17);let y=35;const section=t=>{doc.setTextColor(27,37,33);doc.setFont('helvetica','bold');doc.setFontSize(10);doc.text(t,M,y);y+=6};const space=n=>{if(y+n>195){doc.addPage('a4','landscape');y=18;}};
  section('Rutas registradas');if(!data.tracks.length){doc.setFont('helvetica','normal');doc.setFontSize(7);doc.setTextColor(100);doc.text('Sin rutas registradas.',M,y);y+=8}else for(const t of data.tracks){space(8);const st=trackStats(t),rgb=hexRgb(t.color);doc.setFillColor(...rgb);doc.roundedRect(M,y-2,3,5,1,1,'F');doc.setTextColor(30,40,36);doc.setFont('helvetica','bold');doc.setFontSize(7);doc.text(t.name,M+6,y+1,{maxWidth:90});doc.setFont('helvetica','normal');doc.setTextColor(90);doc.text(`${fmtDist(st.dist)} · ${fmtTime(st.dur)} · ${new Date(t.created).toLocaleDateString('es-MX')}`,M+105,y+1);y+=7;}
  y+=4;section('Puntos de campo');if(!data.waypoints.length){doc.setFont('helvetica','normal');doc.setFontSize(7);doc.setTextColor(100);doc.text('Sin puntos registrados.',M,y)}else for(const w of data.waypoints){space(9);const [code,col]=pointPdfStyle(w.icon),rgb=hexRgb(col);doc.setFillColor(...rgb);doc.circle(M+2.5,y-.6,2.3,'F');doc.setTextColor(255,255,255);doc.setFont('helvetica','bold');doc.setFontSize(3);doc.text(code,M+2.5,y+.2,{align:'center'});doc.setTextColor(30,40,36);doc.setFontSize(7);doc.text(w.name,M+7,y,{maxWidth:80});doc.setFont('helvetica','normal');doc.setTextColor(90);doc.setFontSize(6);doc.text(`${w.lat.toFixed(6)}, ${w.lng.toFixed(6)}${w.notes?' · '+w.notes.slice(0,75):''}`,M+92,y);y+=7;}
  const pages=doc.getNumberOfPages();for(let i=1;i<=pages;i++){doc.setPage(i);doc.setFont('helvetica','normal');doc.setFontSize(5);doc.setTextColor(112);doc.text(`TerraPin Field GIS · ${data.title}`,M,H-4);doc.text(`Página ${i} de ${pages}`,W-M,H-4,{align:'right'});}return{doc,data,filename:`TerraPin-Mapa-${safeFile(data.title)}-${new Date().toISOString().slice(0,10)}.pdf`};
};
const previewLegendHtml=d=>{const l=reportLegendData(d),row=e=>`<div class="map-legend-row"><i style="--c:${esc(e.color)}" class="${e.type}"></i><span>${esc(e.label)}</span></div>`;return `<div class="map-legend"><h5>SIMBOLOGÍA</h5>${l.tracks.length?'<small>Rutas</small>'+l.tracks.map(row).join(''):''}${l.vectors.length?'<small>Capas SIG</small>'+l.vectors.map(row).join(''):''}${l.points.length?'<small>Puntos</small>'+l.points.map(e=>{const [code,col]=pointPdfStyle(e.icon);return `<div class="map-legend-row"><i class="point" style="--c:${col}">${esc(code)}</i><span>${esc(e.label)}</span></div>`}).join(''):''}<div class="map-meta"><b>Información cartográfica</b><span>CRS: WGS 84 · EPSG:4326</span><span>${esc(d.areaName)}</span><span>${d.tracks.length} rutas · ${d.waypoints.length} puntos · ${d.vectors.length} capas</span></div></div>`};
const previewReportBody=d=>`<div class="map-sheet"><div class="map-sheet-head"><img src="icon-512.png"><div><b>${esc(d.title)}</b><span>${esc(d.areaName)}</span></div><aside><strong>MAPA DE PRESENTACIÓN</strong><small>TerraPin Field GIS · ${new Date().toLocaleDateString('es-MX')}</small></aside></div><div class="map-sheet-main"><div class="map-canvas">${reportSvg(d)}</div>${previewLegendHtml(d)}</div><footer><span>Datos TerraPin + capas GIS importadas</span><span>Norte geográfico · Escala gráfica</span></footer></div>`;
const printPreviewData=d=>{const html=`<!doctype html><html><head><meta charset="utf-8"><title>Mapa TerraPin</title><style>@page{size:A4 landscape;margin:8mm}*{box-sizing:border-box}body{font-family:Arial,sans-serif;color:#17201d;margin:0}.map-sheet{width:100%}.map-sheet-head{height:23mm;background:#101714;color:#fff;border-radius:5mm;padding:3mm 4mm;display:flex;align-items:center;gap:4mm}.map-sheet-head img{width:17mm;height:17mm;background:#fff;border-radius:4mm}.map-sheet-head div{flex:1}.map-sheet-head b,.map-sheet-head span,.map-sheet-head aside strong,.map-sheet-head aside small{display:block}.map-sheet-head b{font-size:16pt}.map-sheet-head span{font-size:8pt;color:#d3e2db;margin-top:1mm}.map-sheet-head aside{text-align:right}.map-sheet-head aside strong{font-size:6.5pt;color:#c5a66b}.map-sheet-head aside small{font-size:6pt;margin-top:2mm;color:#d3e2db}.map-sheet-main{display:grid;grid-template-columns:3.15fr 1fr;gap:3mm;margin-top:3mm}.map-canvas{background:#f3f1ea;border:1px solid #d8d5cc;border-radius:3mm;padding:1mm}.map-canvas svg{display:block;width:100%;height:auto}.map-legend{border:1px solid #dedad0;background:#faf9f5;border-radius:3mm;padding:4mm}.map-legend h5{font-size:7pt;margin:0 0 3mm}.map-legend small{display:block;font-size:5.5pt;color:#7a827e;text-transform:uppercase;margin:2mm 0 1mm}.map-legend-row{display:flex;align-items:center;gap:2mm;font-size:5.5pt;margin:1.2mm 0}.map-legend-row i{width:7mm;height:1.4mm;background:var(--c);border-radius:2mm}.map-legend-row i.polygon{height:4mm;opacity:.55}.map-legend-row i.point{height:5mm;width:5mm;border-radius:50%;color:#fff;display:grid;place-items:center;font-size:3.5pt}.map-meta{border-top:1px solid #dedad0;margin-top:3mm;padding-top:3mm;font-size:5pt}.map-meta b,.map-meta span{display:block;margin-top:1.2mm}footer{display:flex;justify-content:space-between;border-top:1px solid #dedad0;margin-top:3mm;padding-top:2mm;font-size:5pt;color:#6b746f}</style></head><body>${previewReportBody(d)}</body></html>`;const f=document.createElement('iframe');f.style.cssText='position:fixed;width:1px;height:1px;right:0;bottom:0;border:0;opacity:0';document.body.appendChild(f);f.srcdoc=html;f.onload=()=>setTimeout(()=>{try{f.contentWindow.focus();f.contentWindow.print()}catch{}setTimeout(()=>f.remove(),3000)},300);};
const savePdfFile=async(doc,filename)=>{const blob=doc.output('blob');const file=typeof File!=='undefined'?new File([blob],filename,{type:'application/pdf'}):null;if(file&&navigator.share&&navigator.canShare?.({files:[file]})){await navigator.share({title:'Mapa TerraPin',text:'Mapa cartográfico generado en TerraPin',files:[file]});}else{downloadBlob(filename,blob);toast('PDF guardado')}};
const saveReportAreaName=async(projectId,name)=>{if(projectId){const p=S.projects.find(x=>x.id===projectId);if(p)p.areaName=name}else S.settings.reportAreaName=name;await save();};
const previewReportPdf=async(projectId,preferPrint=false)=>{try{let area=projectId?(S.projects.find(p=>p.id===projectId)?.areaName||'Área de trabajo'):(S.settings.reportAreaName||'Área de trabajo');let bundle=await createReportPdf(projectId,area);openModal(`<div class="modal-kicker">COMPOSICIÓN CARTOGRÁFICA</div><div class="preview-head"><div><h3>Mapa profesional</h3><p>Edita el nombre del área y revisa la lámina antes de guardarla.</p></div><span class="format-pill">A4 HORIZONTAL · PDF</span></div><div class="map-config"><label>Nombre del área</label><div><input id="pdfAreaName" value="${esc(area)}"><button class="btn sm ghost" id="pdfRefresh">Actualizar mapa</button></div></div><div class="pdf-preview-wrap map-preview" id="pdfPreview">${previewReportBody(bundle.data)}</div><div class="actions preview-actions"><button class="btn ghost" data-close>Cerrar</button><button class="btn ghost" id="pdfPrint">Imprimir</button><button class="btn" id="pdfSave">Guardar PDF</button></div>`);const rebuild=async()=>{area=$('#pdfAreaName').value.trim()||'Área de trabajo';await saveReportAreaName(projectId,area);bundle=await createReportPdf(projectId,area);$('#pdfPreview').innerHTML=previewReportBody(bundle.data);return bundle};$('#pdfRefresh').onclick=rebuild;$('#pdfSave').onclick=async()=>{const b=await rebuild();await savePdfFile(b.doc,b.filename)};$('#pdfPrint').onclick=async()=>{const b=await rebuild();printPreviewData(b.data)};if(preferPrint)setTimeout(()=>$('#pdfPrint')?.focus(),80)}catch(e){console.error(e);toast('No se pudo generar la composición cartográfica')}};
const shareOrDownloadPdf=projectId=>previewReportPdf(projectId,false);const printReport=projectId=>previewReportPdf(projectId,true);
'''
app=app[:rstart]+report+app[rend:]

# Project edit: area name field and save
old="""<div class="field"><label>Nombre</label><input id="epName" value="${esc(p.name)}"></div><div class="field"><label>Carpeta</label>"""
new="""<div class="field"><label>Nombre</label><input id="epName" value="${esc(p.name)}"></div><div class="field"><label>Nombre del área para mapas/PDF</label><input id="epArea" value="${esc(p.areaName || '')}" placeholder="Ej. Lote 13–14 · Área de actividad"></div><div class="field"><label>Carpeta</label>"""
assert old in app
app=app.replace(old,new,1)
oldsave="p.name = $('#epName').value.trim() || p.name; p.folderId = $('#epFolder').value || null; await save();"
newsave="p.name = $('#epName').value.trim() || p.name; p.areaName = $('#epArea').value.trim(); p.folderId = $('#epFolder').value || null; await save();"
assert oldsave in app
app=app.replace(oldsave,newsave,1)

# About version and report label
app=app.replace('Genera un informe moderno con croquis, rutas, métricas y puntos de campo.','Genera una lámina cartográfica profesional con simbología, norte, escala, rutas, capas y puntos.')

# route tail note markup
old='<div class="route-choices" id="routeChoices"></div>'
new='<div class="route-tail-note" id="routeTailNote"></div><div class="route-choices" id="routeChoices"></div>'
assert old in idx
idx=idx.replace(old,new,1)

# Splash & status label
idx=idx.replace('SIG móvil de campo · navegación inteligente · trabajo offline','Cartografía móvil · navegación híbrida · operación de campo')

# Append 2.5 CSS before closing style
css=r'''
/* -------- TerraPin 2.5 · Expedition Luxe UI -------- */
:root{--lux-ink:#101714;--lux-ivory:#F6F4EE;--lux-paper:#FCFBF7;--lux-green:#0E705D;--lux-mint:#35C7A0;--lux-gold:#B99A60;--lux-line:rgba(20,31,27,.11);--lux-shadow:0 24px 70px rgba(8,24,19,.24)}
body{background:#dfe6e0}.leaflet-container{font-family:Manrope,Inter,system-ui,sans-serif}.leaflet-control-zoom{border:0!important;box-shadow:0 14px 38px rgba(8,24,19,.22)!important;border-radius:16px!important;overflow:hidden}.leaflet-control-zoom a{border:0!important;background:rgba(246,244,238,.94)!important;color:#14211c!important}
.topbar{top:max(9px,env(safe-area-inset-top));left:9px;right:9px;grid-template-columns:1fr 43px;gap:9px;padding:9px 10px 10px;border-radius:24px;background:rgba(246,244,238,.94);border:1px solid rgba(255,255,255,.78);box-shadow:0 20px 65px rgba(8,24,19,.22);backdrop-filter:blur(30px) saturate(150%);-webkit-backdrop-filter:blur(30px) saturate(150%)}
[data-theme="dark"] .topbar{background:rgba(15,22,19,.95);border-color:rgba(255,255,255,.08)}.brand .logo{width:43px;height:43px;border-radius:14px;background:#fff;box-shadow:0 8px 24px rgba(11,57,47,.13)}.brandcopy b{font-family:Manrope,Inter,sans-serif;font-size:19px;font-weight:850;letter-spacing:-.65px;color:var(--lux-ink)}[data-theme="dark"] .brandcopy b{color:#F7F5EE}.brandcopy small{color:#60716A;font-size:10px;font-weight:700}.live-chip{height:24px;padding:0 8px;border-radius:999px;background:#161F1B;color:#F6F4EE;border:1px solid rgba(185,154,96,.55);font-size:8px;letter-spacing:.7px}.live-chip i{background:var(--lux-mint);box-shadow:0 0 0 4px rgba(53,199,160,.12)}.live-chip b{font-size:7px;color:#D5B978;margin-left:3px}
.themebtn{background:transparent!important;color:#44514C!important;border:1px solid var(--lux-line)!important;box-shadow:none!important}.search{height:46px;border-radius:15px;background:#161F1B;box-shadow:none;padding:0 4px 0 12px}.searchlead{color:#9CB0A7}.search input{color:#F9F7F1!important;font-size:13px}.search input::placeholder{color:#7F928A}.search button{height:38px;border-radius:12px;background:linear-gradient(135deg,#147C67,#32B992);padding:0 15px;box-shadow:0 8px 18px rgba(20,124,103,.22)}
.fabcol{top:168px;right:10px;gap:7px;padding:6px;border-radius:20px;background:rgba(16,23,20,.93);box-shadow:var(--lux-shadow);border:1px solid rgba(255,255,255,.08);backdrop-filter:blur(20px)}.fabcol .iconbtn{width:45px;height:45px;border-radius:14px;background:transparent;color:#DDE9E3;border:0;box-shadow:none}.fabcol .iconbtn+ .iconbtn{border-top:1px solid rgba(255,255,255,.08);border-radius:0;padding-top:8px}.fabcol .iconbtn.active,.fabcol .iconbtn.gps-on{background:#F6F4EE;color:#0E705D;border-radius:13px!important}.gpsdot{border-color:#101714}
.map-hud{left:10px;bottom:96px;border-radius:14px;background:rgba(16,23,20,.88);border:1px solid rgba(255,255,255,.08);box-shadow:0 12px 34px rgba(8,24,19,.22);font-size:9px;letter-spacing:.2px}.map-hud i.on{background:rgba(53,199,160,.16);color:#8BE7CB}.recbar{left:10px;right:72px;bottom:96px;border-radius:20px;background:rgba(246,244,238,.96);border:1px solid rgba(255,255,255,.78);box-shadow:0 18px 48px rgba(8,24,19,.2)}
.nav{left:9px;right:9px;bottom:max(7px,env(safe-area-inset-bottom));height:76px;border-radius:25px;background:#101714;border:1px solid rgba(255,255,255,.06);box-shadow:0 24px 66px rgba(7,20,16,.4);padding:7px 8px}.nav button{color:#7F928A;border-radius:17px;font-size:9px;font-weight:760}.nav button svg{width:21px;height:21px}.nav button.active{background:var(--lux-ivory);color:#10201A;box-shadow:none;transform:none}.nav button.active svg{stroke:#0E705D}.nav:before{content:"";position:absolute;left:18px;right:18px;top:0;height:1px;background:linear-gradient(90deg,transparent,rgba(185,154,96,.55),transparent)}
.sheet{bottom:91px;border-radius:28px 28px 22px 22px;background:rgba(252,251,247,.97);border:1px solid rgba(255,255,255,.8);box-shadow:0 30px 90px rgba(8,24,19,.3)}[data-theme="dark"] .sheet{background:rgba(17,26,22,.98)}.sheet header h2{font-size:22px;font-weight:850;letter-spacing:-.65px}.sheet .grab{background:#C6C7C0}.card,.item,.point-card{border-color:rgba(18,35,29,.08);box-shadow:0 8px 26px rgba(9,47,38,.05)}.btn{border-radius:14px;background:linear-gradient(135deg,#0E705D,#24A988);box-shadow:0 9px 22px rgba(14,112,93,.16)}.btn.ghost{background:#EEEDE7;color:#26332E;box-shadow:none}
.selected-point-card{left:10px;right:10px;bottom:96px;border-radius:26px;padding:13px;background:rgba(252,251,247,.98);border:1px solid rgba(255,255,255,.8);box-shadow:0 25px 72px rgba(8,24,19,.28)}.selected-point-card:before{content:"DESTINO";position:absolute;right:48px;top:11px;font-size:8px;font-weight:900;letter-spacing:1.2px;color:#B99A60}.sp-icon{background:#101714;color:#F6F4EE;border-radius:17px}.sp-copy small{color:#0E705D}.sp-navigate{background:#101714;color:#fff;box-shadow:none}.sp-actions>button:first-child{background:#ECEBE5}.route-card{bottom:96px;border-radius:26px;background:#101714;border:1px solid rgba(185,154,96,.28);box-shadow:0 30px 80px rgba(5,18,14,.42)}.route-arrow{background:linear-gradient(145deg,#0E705D,#35C7A0)}.route-tail-note{display:none;margin-top:9px;padding:8px 10px;border-radius:12px;background:rgba(255,255,255,.07);font-size:10px;color:#BCD2C9}.route-tail-note.visible{display:block}.route-tail-note.direct{background:rgba(185,154,96,.16);color:#F1D596;border:1px solid rgba(185,154,96,.22)}.route-choice.active{background:#F6F4EE;color:#16231D}.route-metrics>div{background:rgba(255,255,255,.06)}.route-metrics button{background:#F6F4EE;color:#17352B}
.modal{background:rgba(6,14,11,.55);backdrop-filter:blur(9px)}.modal .box{border-radius:28px;background:#FCFBF7;border:1px solid rgba(255,255,255,.8);box-shadow:0 36px 100px rgba(4,16,12,.35)}[data-theme="dark"] .modal .box{background:#121C18}.modal-kicker{color:#A6844E}.format-pill{background:#101714;color:#EBD7AE;border:1px solid rgba(185,154,96,.4)}
.map-config{margin:12px 0;padding:12px;border-radius:18px;background:#F0EFE9;border:1px solid #E1DED5}.map-config label{display:block;font-size:10px;font-weight:850;color:#58645F;margin-bottom:6px}.map-config>div{display:grid;grid-template-columns:1fr auto;gap:8px}.map-config input{height:42px;border-radius:13px;border:1px solid #D5D4CD;background:#fff;padding:0 12px;font-weight:750;color:#17211D}.map-preview{background:#D9D8D2!important;border-radius:20px!important;padding:12px!important}.map-sheet{min-width:760px;background:#FCFBF7;padding:13px;border-radius:10px;color:#17211D}.map-sheet-head{height:76px;background:#101714;color:#fff;border-radius:16px;padding:12px 14px;display:flex;align-items:center;gap:12px}.map-sheet-head img{width:54px;height:54px;background:#fff;border-radius:14px}.map-sheet-head>div{flex:1}.map-sheet-head b,.map-sheet-head span,.map-sheet-head aside strong,.map-sheet-head aside small{display:block}.map-sheet-head b{font-size:20px;letter-spacing:-.5px}.map-sheet-head span{font-size:10px;color:#C8D8D1;margin-top:4px}.map-sheet-head aside{text-align:right}.map-sheet-head aside strong{font-size:9px;color:#D4B578;letter-spacing:.9px}.map-sheet-head aside small{font-size:8px;color:#C8D8D1;margin-top:5px}.map-sheet-main{display:grid;grid-template-columns:3.1fr 1fr;gap:10px;margin-top:10px}.map-canvas{min-height:340px;background:#F3F1EA;border:1px solid #D8D5CC;border-radius:14px;padding:5px}.carto-svg{width:100%;height:auto;display:block}.map-legend{border:1px solid #DFDCD3;background:#FAF9F5;border-radius:14px;padding:12px}.map-legend h5{font-size:10px;margin:0 0 10px;letter-spacing:.8px}.map-legend small{display:block;font-size:8px;color:#818A85;text-transform:uppercase;margin:9px 0 5px}.map-legend-row{display:flex;align-items:center;gap:8px;font-size:9px;margin:6px 0}.map-legend-row i{width:24px;height:4px;background:var(--c);border-radius:4px}.map-legend-row i.polygon{height:12px;opacity:.55}.map-legend-row i.point{width:18px;height:18px;border-radius:50%;display:grid;place-items:center;color:#fff;font-size:7px;font-style:normal}.map-meta{border-top:1px solid #DFDCD3;margin-top:12px;padding-top:9px;font-size:8px}.map-meta b,.map-meta span{display:block;margin-top:4px}.map-sheet footer{display:flex;justify-content:space-between;margin-top:9px;padding-top:7px;border-top:1px solid #DFDCD3;font-size:8px;color:#6C7771}
.splash{background:radial-gradient(circle at 50% 35%,#1F4C3E 0,#101714 45%,#070B09 100%)}.splash h1{font-size:35px;letter-spacing:-1.2px}.splash p{color:#C5D4CD}.splash small{color:#8A9A93}.splash:after{content:"FIELD GIS 2.5";margin-top:15px;padding:7px 12px;border:1px solid rgba(185,154,96,.45);border-radius:999px;color:#D6BA83;font-size:9px;letter-spacing:1.5px;font-weight:850}
@media(min-width:700px){.topbar{width:min(700px,calc(100vw - 28px))}.nav{width:min(650px,calc(100vw - 36px))}.selected-point-card,.route-card{width:min(680px,calc(100vw - 32px))}.fabcol{right:calc(50% - 355px)}}
'''
idx=idx.replace('\n</style>',css+'\n</style>',1)

app_p.write_text(app); idx_p.write_text(idx); sw_p.write_text(sw); pkg_p.write_text(pkg); man_p.write_text(man)
print('patched 2.5',len(app),len(idx),len(sw))
